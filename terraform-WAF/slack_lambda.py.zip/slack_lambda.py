import urllib3
import json
import base64
import gzip
import os
from datetime import datetime

http = urllib3.PoolManager()

def get_log_events_message(event):
    # Parse the CloudWatch log event
    log_data = event['awslogs']['data']
    compressed_payload = base64.b64decode(log_data)
    uncompressed_payload = gzip.decompress(compressed_payload)
    log_events = json.loads(uncompressed_payload)['logEvents']
    data = json.loads(log_events[0]['message'])
    return data
    
def format_slack_message(data):
    timestamp = data['timestamp']
    formattedTime = datetime.fromtimestamp(timestamp/1000).strftime('%d-%m-%y-%H:%M:%S')
    action = data['action']
    ruleGroupList = data['ruleGroupList']
    
    for ruleGroup in ruleGroupList:
        if (ruleGroup['terminatingRule'] != None):
            ruleGroupId = ruleGroup['ruleGroupId']
            ruleId = ruleGroup['terminatingRule']['ruleId']
    
    return {
        "blocks": [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": ":red_circle:" + f" Warning! AWS WAF triggered" + f" at {formattedTime}" + f" Action: {action}"
                },
            },
            {
                "type": "divider"
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text":  f"Rule Group ID: {ruleGroupId}"
                },
                "block_id": "ruleBlock"
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text":  f" Reason: {ruleId}"
                },
                "block_id": "reasonBlock"
            }
        ]
    }
    

def lambda_handler(event, context):
    data = get_log_events_message(event)
    msg = format_slack_message(data)
    
    encoded_msg = json.dumps(msg).encode("utf-8")
    resp = http.request("POST", os.getenv('SLACK_WEBHOOK_URL'), body=encoded_msg)
    print(
        {
            "message": msg,
            "status_code": resp.status,
            "response": resp.data,
        }
    )
